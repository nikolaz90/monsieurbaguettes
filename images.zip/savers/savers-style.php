<style>  
    .answer-box{
        display: block;
        

    }
</style>